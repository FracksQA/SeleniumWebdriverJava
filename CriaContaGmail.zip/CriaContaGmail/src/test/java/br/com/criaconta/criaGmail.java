package br.com.criaconta;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class criaGmail {
	
	public void tc() throws InterruptedException, EncryptedDocumentException, InvalidFormatException, IOException {

		WebDriver driver = new ChromeDriver();

		driver.get("https://accounts.google.com/signup/v2/webcreateaccount?flowName=GlifWebSignIn&flowEntry=SignUp");
		
		ArrayList<String> nome = readExcelData(0);
		
		ArrayList<String> sobrenome = readExcelData(1);
		
		ArrayList<String> nomeusua = readExcelData(2);
		
		ArrayList<String> senha = readExcelData(3);
		
		ArrayList<String> confirmsenha = readExcelData(4);
		
		ArrayList<String> emailrecup = readExcelData(5);
		
		//ArrayList<String> dia = readExcelData(6);
		
		//ArrayList<String> mes = readExcelData(7);
		
		//ArrayList<String> ano = readExcelData(8);
		
		for(int i = 0; i <nome.size(); i++) {

		Thread.sleep(500);
        
		//clica em criar conta
		//driver.findElement(By.xpath("")).click();

		//Thread.sleep(500);
        
		//preenche nome
		driver.findElement(By.xpath("//*[@id=\"firstName\"]")).sendKeys(nome.get(i));

		Thread.sleep(500);
        
		//preenche sobrenome
		driver.findElement(By.xpath("//*[@id=\"lastName\"]")).sendKeys(sobrenome.get(i));

		Thread.sleep(500);

		//preenche nome de usuario
		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys(nomeusua.get(i));
		
		Thread.sleep(500);
		
		//preenche senha
		driver.findElement(By.xpath("//*[@id=\"passwd\"]/div[1]/div/div[1]/input")).sendKeys(senha.get(i));
		
		Thread.sleep(3500);
		
		//confirma senha
		driver.findElement(By.xpath("//*[@id=\"confirm-passwd\"]/div[1]/div/div[1]/input")).sendKeys(confirmsenha.get(i));
		
		//clica em proximo
		driver.findElement(By.xpath("//*[@id=\"accountDetailsNext\"]/content/span")).click();
		
		Thread.sleep(500);
		
		//preenche email de recuperação
		driver.findElement(By.xpath("//*[@id=\"view_container\"]/form/div[2]/div/div[2]/div/div[1]/div/div[1]/input")).sendKeys(emailrecup.get(i));
		
		Thread.sleep(500);
		
		//clica em dia
		driver.findElement(By.xpath("//*[@id=\"day\"]")).click();
		
		Thread.sleep(500);
		
		//preenche dia
		driver.findElement(By.xpath("//*[@id=\"day\"]")).sendKeys("29");
		
		Thread.sleep(500);
		
		//clica em mes
		driver.findElement(By.xpath("//*[@id=\"month\"]")).click();
		
		Thread.sleep(500);
		
		
		//preenche mes
		driver.findElement(By.xpath("//*[@id=\"month\"]")).sendKeys("Fevereiro");
		
		Thread.sleep(500);
		
		//clica em ano
		driver.findElement(By.xpath("//*[@id=\"year\"]")).click();
		
		Thread.sleep(500);
		
		//preenche ano
		driver.findElement(By.xpath("//*[@id=\"year\"]")).sendKeys("1999");
		
		Thread.sleep(500);
		
		//escolhe sexo
		driver.findElement(By.xpath("//*[@id=\"gender\"]")).click();
		
		Thread.sleep(500);
		
		driver.findElement(By.xpath("//*[@id=\"gender\"]/option[4]")).click();
		
		Thread.sleep(500);
		
		//clica em proxima
		driver.findElement(By.xpath("//*[@id=\"personalDetailsNext\"]/content/span")).click();
		
		Thread.sleep(500);
		
		//clica na seta
		driver.findElement(By.xpath("//*[@id=\"view_container\"]/form/div[2]/div/div/div/div[1]/div/div/content/span/svg")).click();
		
		Thread.sleep(500);
		
		//clica em concordo
		driver.findElement(By.xpath("//*[@id=\"termsofserviceNext\"]/content/span")).click();
		
		Thread.sleep(800);
				
		driver.close();
		
		
		}

	}

	public ArrayList<String> readExcelData(int coluNumber) throws EncryptedDocumentException, InvalidFormatException, IOException {

		FileInputStream fis = new FileInputStream("C:\\Users\\pc\\Desktop\\perfgmail.xlsx");

		XSSFWorkbook wb = (XSSFWorkbook) WorkbookFactory.create(fis);

		Sheet s = wb.getSheet("criaMassa");

		Iterator<Row> rowIterator = s.iterator();

		rowIterator.next();

		ArrayList<String> list = new ArrayList<String>();

		while (rowIterator.hasNext()) {

			list.add(rowIterator.next().getCell(coluNumber).getStringCellValue());

		}

		System.out.println("List :::: " + list);
		return list;
	}

	public static void main(String[] args) throws EncryptedDocumentException, InvalidFormatException, IOException, InterruptedException {

		criaGmail data = new criaGmail();

		data.tc();
		
		

	}

}
